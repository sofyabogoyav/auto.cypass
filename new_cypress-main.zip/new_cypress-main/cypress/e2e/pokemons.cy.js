describe('Покупка аватара e2e', function () {

     it('Покупка аватара e2e', function () {
        cy.visit('https://pokemonbattle.ru/'); 
        cy.get('#k_email').type('[user_name]');
        cy.get('#k_password').type('[user_password]');
        cy.get('.MuiButton-root').click();
        cy.get('.style_1_heading_38_400_pokemon_classic').contains('Покемоны');
        cy.get('.header_card_trainer').click();
        cy.get('[data-qa="shop"]').click();
        cy.get('.available > button').first().click();
        cy.get('.card_number').type('5555 5555 5555 5599');                     // вводим номер карты
         cy.get('.card_csv').type('125');                             // вводим CVV карты
         cy.get('.card_date').type('1230');                           // вводим срок действия карты
         cy.get('.card_name').type('NAME Name');                           // вводим имя владельца действия карты
         cy.get('.style_1_base_button_payment_body > .style_1_base_button_payment').click();     // нажимаем кнопку Оплатить
         cy.get('.threeds_number').type('56456');                            // вводим код подтверждения СМС
         cy.get('.style_1_base_button_payment_body > .style_1_base_button_payment').click();   // нажимаем кнопку Оплатить
         cy.contains('Покупка прошла успешно').should('be.visible'); 
         cy.get('.style_1_base_link_blue').should('be.visible')
        })
})